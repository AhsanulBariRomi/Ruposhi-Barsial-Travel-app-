package com.example.msipc.ruposhibarisal;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by MSI PC on 1/26/2017.
 */

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "TourExpense.db";
    public static final String TABLE_NAME = "Tour_Expense";

    public static final String col1="ID";
    public static final String col2="TRANSPORT";
    //public static final String col3="FOOD";
    //public static final String col4="ACCOMODATION";
    //public static final String col5="OTHERS";

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        //SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, TRANSPORT TEXT) ");
    }

    //, FOOD TEXT, ACCOMODATION TEXT, OTHERS TEXT,TOTAL TEXT

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }


//, String Food,String Accomodation,String Others,String Total
    public boolean insertData(String Transport){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(col2,Transport);
        //contentValues.put(col3,Food);
        //contentValues.put(col4,Accomodation);
        //contentValues.put(col5,Others);
        //contentValues.put(col6,Total);

        long result = db.insert(TABLE_NAME,null,contentValues);

        if(result == -1)
            return  false;
        else
            return  true;
    }
}
