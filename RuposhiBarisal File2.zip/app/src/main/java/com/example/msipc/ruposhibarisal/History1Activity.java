package com.example.msipc.ruposhibarisal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class History1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history1);
    }
    public void gotoHistory2(View v){
        Intent i = new Intent(getApplicationContext(),History2Activity.class) ;
        startActivity(i);
    }
}
