package com.example.msipc.ruposhibarisal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CommunicationnActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_communicationn);
    }

    public void gotoBus(View v){
        Intent i = new Intent(getApplicationContext(),BussActivity.class) ;
        startActivity(i);
    }

    public void gotoRiver(View v){
        Intent i = new Intent(getApplicationContext(),RiverporttActivity.class) ;
        startActivity(i);
    }


    public void gotoAir(View v){
        Intent i = new Intent(getApplicationContext(),ByAirrActivity.class) ;
        startActivity(i);
    }
}
