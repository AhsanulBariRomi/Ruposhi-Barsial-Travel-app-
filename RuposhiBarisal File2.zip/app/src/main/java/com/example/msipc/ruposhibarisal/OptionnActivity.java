package com.example.msipc.ruposhibarisal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class OptionnActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optionn);
        Intent i = getIntent();
    }

    public void gotoHistory(View v){
        Intent i = new Intent(getApplicationContext(),History1Activity.class) ;
        startActivity(i);
    }
    public void gotoCom(View v){
        Intent i = new Intent(getApplicationContext(),CommunicationnActivity.class) ;
        startActivity(i);
    }

    public void gotoCalculator(View v){
        Intent i = new Intent(getApplicationContext(),CalculatorActivity.class) ;
        startActivity(i);
    }

    public void gototourist(View v){
        Intent i = new Intent(getApplicationContext(),TouristActivity.class) ;
        startActivity(i);
    }
    public void gotofood(View v){
        Intent i = new Intent(getApplicationContext(),FoodsActivity.class) ;
        startActivity(i);
    }

    public void gotoAccommo(View v){
        Intent i = new Intent(getApplicationContext(),AccommodationActivity.class) ;
        startActivity(i);
    }
}
