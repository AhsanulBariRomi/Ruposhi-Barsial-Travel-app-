package com.example.msipc.calculatorforruposhibarisal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText romizIput;
    TextView romizText;
    MyDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       romizIput = (EditText)findViewById(R.id.TRE);
        romizText = (TextView)findViewById(R.id.savedisplay);
        dbHandler = new MyDBHandler(this,null,null,1);
        printDatabase();
    }

    //Add an expense to the database
    public void saveButtonClick(View v){
        Product product = new Product(romizIput.getText().toString());
       // Toast.makeText(MainActivity.this,"oishee",Toast.LENGTH_SHORT).show();


        dbHandler.addExpense(product);
        printDatabase();
    }

    //Delete an expense from the database
    public void deleteButtonClicked(View v){
        String inputText = romizIput.getText().toString();
        //dbHandler.deleteExpense(inputText);
        printDatabase();
    }


    public void printDatabase(){
        String dbString = dbHandler.databaseToString();
        romizText.setText(dbString);
        romizIput.setText("");
    }

    public void onButtonClick(View v){
        EditText e1 = (EditText)findViewById(R.id.TRE);
        EditText e2 = (EditText)findViewById(R.id.FOE);
        EditText e3 = (EditText)findViewById(R.id.ACE);
        EditText e4 = (EditText)findViewById(R.id.OTHERE);

        TextView t1 = (TextView)findViewById(R.id.TOTALEX);

        int num1 = Integer.parseInt(e1.getText().toString());
        int num2 = Integer.parseInt(e2.getText().toString());
        int num3 = Integer.parseInt(e3.getText().toString());
        int num4 = Integer.parseInt(e4.getText().toString());

        int sum = num1 + num2 + num3 + num4;

        t1.setText(Integer.toString(sum));
    }
}
