package com.example.msipc.calculatorforruposhibarisal;
/**
 * Created by MSI PC on 2/5/2017.
 */
public class Product {

    private int _id;
    private String transExpense;

    public Product(){
    }

    public Product(String transExpense) {      //alt+insert
        this.transExpense = transExpense;
    }

    public void set_transExpense(String _transExpense) {
        this.transExpense = _transExpense;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public int get_id() {
        return _id;
    }

    public String get_transExpense() {

        return transExpense;
    }
}
